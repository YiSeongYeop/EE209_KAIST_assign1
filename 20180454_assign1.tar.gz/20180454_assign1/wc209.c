/*
* name: Lee Seong Yeop 20180454
* assignment number: 1
* file name: wc209.c
*/
#include <stdio.h>
#include <ctype.h>
#include <assert.h>
#include <stdlib.h>
enum DFAState {IN, OUT};

enum DFAState state = OUT;
int array_size = 1;
int current_place = 0;
int linenum;
int wordnum;
int alphanum;
int digitnum;
int othernum;

/*
* counting line function: this function has parameter
* int *string_array and return linenum. this function 
* count line when string_array's current place element
* is newline character.
* parameter: int *string_array, return value: linenum
* used global variables: current_place, linenum
*/
int count_line(int *string_array) {
	if (string_array[current_place] == '\n')
		linenum++;
	return linenum;
}


/*
* counting word function: this function has parameter
* int *string_array and return int 0. this function
* add 1 to word number if state is changed OUT to IN. 
* parameter: int *string_array, return value: int 0
* used global variables: current_place, state, wordnum
*/
int count_word(int *string_array) {
	switch (state) {
	case IN:
		if (isspace(string_array[current_place])) state = OUT;
		break;
	case OUT:
		if (!isspace(string_array[current_place])) {state = IN; 
			wordnum++;}
		break;
	default:
		assert(0); 
		break;
	}
	return 0;
}

/*
* counting alphabet, digit and other character function: 
* this function has parameter int *string_array and return int 0.
* this function counts alphabet, digit, others according to
* string_array's current place element.
* parameter: int *string_array, return value: int 0
* used global variables: current_place, alphanum, 
* digitnum, othernum
*/
int count_char(int *string_array) { 
	if (isalpha(string_array[current_place]))
		alphanum++;
	else if (isdigit(string_array[current_place]))
		digitnum++;
	else
		othernum++;
	return 0;
}

/*
* managing comment function: this function has parameter 
* int *string_array and return int 0 or int 1, which is 
* act like flag, this function ignore characters inside 
* comment except newline char.
* parameter: int *string_array, return value: int 0 or int 1 (flag)
* used global variables: current_place, array_size, 
* linenum, othernum, state
*/
int manage_comment(int *string_array) { 
	if (string_array[current_place] == '/') {
		if ((current_place + 1) >= array_size){ 
			return 0;
		}
		int next_char = string_array[current_place + 1];

		if (next_char == '*') { 
			current_place = current_place + 2; 

			while (((string_array[current_place] != '*') ||
			 (string_array[current_place + 1] != '/')) &&
			  ((current_place + 1) < array_size)) { 
				int temp_linenum = linenum;
				count_line(string_array); 
				if (linenum != temp_linenum)
					count_char(string_array); 
				current_place++;
			}

			if ((string_array[current_place] == '*') && 
				(string_array[current_place + 1] == '/')) { 
				othernum++;
				state = OUT;

				current_place = current_place + 2;
				return 1; 
			}
			else if ((current_place + 1) >= array_size) { 
				printf("Error: line %d: unterminated comment", 
					linenum+1);
				current_place++;
				return EXIT_FAILURE;
			}
			return 0;
		}
		else if (next_char == '/') { 
			return 0;
		}
		else { 
			return 0;
		}
	}
	return 0;
}

/*
* starting function: it gets void type parameter and return int 0,
* this function is main of total code.
* parameter: void, return value: int 0
* used global variables: current_place, array_size, 
* linenum, wordnum, alphanum, digitnum, othernum
*/
int main (void) {
	int c;
	int *string_array = (int *)malloc(array_size*sizeof(int));

	while ((c = getchar()) != EOF) { 
		string_array[array_size-1] = c;
		array_size++;
		string_array = (int *)realloc(string_array, array_size*sizeof(int));
	}
	array_size--;

	while (current_place < array_size) {
		if (manage_comment(string_array))
			continue;
		count_line(string_array);
		count_word(string_array);
		count_char(string_array);

		current_place++;
	}

	printf("%d %d %d\n", linenum + 1, wordnum, alphanum + 
		digitnum + othernum);

	free(string_array);

	return 0;
}
